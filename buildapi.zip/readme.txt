This is how you run the project


1) Activate the virtual environment using this command line --> source env/bin/activate
2) Change directory to the second buildapi folder --> cd buildapi
3) Run the server using this commant --> python manage.py runserver

Notes:
The end points aren't deployed, so if you have any problems running the project and
you want me to deploy them or send you a documented pictures and videos running the task this would
definitely be fine and will only take a couple of minutes to do so.